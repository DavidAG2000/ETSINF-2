package aplicaciones.indices;

import testIndex.TestIndexador;
/**
 * Write a description of class TestIndexadorL here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestIndexBib {
    public static void main(String[] args) {
        String[] argv = {}; 
        TestIndexador.main(argv);
    }
}