// Program SequentialAdd.c
// Compile with:
//   gcc SequentialAdd.c -o SeqAdd -lm

#include <stdio.h>
#include <pthread.h>
#include <math.h>
#include <string.h>
#include <unistd.h>

#define DIMROW 1000000
#define NUMROWS 20

typedef struct row{
        int vector[DIMROW];
        long addition;
} row;

row matrix[NUMROWS];

void *AddRow( void *ptr )
{
    int k;
    row *fi;
    fi=(row *)  ptr;

    fi->addition=0;
    for(k=0;k<DIMROW;k++) {
        fi->addition += exp((k*(fi->vector[k])+
                       (k+1)*(fi->vector[k]))/(fi->vector[k]+2*k))/2;
    }
}

int main()
{
    int i,j;
    long total_addition=0;
    pthread_attr_t atrib;

    // Vector elements initialized to 1
    for(i=0;i<NUMROWS;i++) {
        for(j=0;j<DIMROW;j++) {
            matrix[i].vector[j]=1;
        }
    }
    // Thread attributes initialization
    pthread_attr_init( &atrib );
	
    // EXERCISE 2.a
	int numcores = 4;//system("<< grep processor /proc/cpuinfo | wc -l");
 	pthread_t threads[4];
	int thread_args[4];
	int rc;
	int NUMROW_RESTANTES=NUMROWS;
	int conterNomROWS=0;

while(NUMROW_RESTANTES!=0){
	//printf("NUMROW_RESTANTES %d\n", NUMROW_RESTANTES);
	    for(i=0;i<4;i++){
	      thread_args[i] = i;
              //printf("----->NUMROWs %d\n", conterNomROWS);  
	      rc = pthread_create(&threads[i], NULL, AddRow, (void *) &matrix[conterNomROWS]);
	      conterNomROWS=conterNomROWS+1; 
	    }   
	NUMROW_RESTANTES = NUMROW_RESTANTES-4;
}    
 

  for (i=0; i<4; ++i) {
    rc = pthread_join(threads[i], NULL);
	int j;
	for (j = NUMROWS / 4 * i; j < NUMROWS / 4 * (i + 1); j++) {
		total_addition += matrix[i].addition;
	}

  }
printf("Total addition is: %ld\n", total_addition);

// EXERCISE 2.b

    /**for(i=0;i<NUMROWS;i++) 
        total_addition+=matrix[i].addition;
    printf(  "Total addition is: %ld\n",total_addition);**/

}

/**
TH2 ->Total addition is: 20000000

real	0m0.362s
user	0m0.876s
sys	0m0.028s


TH -> Total addition is: 20000000

real	0m0.485s
user	0m0.960s
sys	0m0.120s


**/

