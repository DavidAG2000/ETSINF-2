// Program SequentialAdd.c
// Compile with:
//   gcc SequentialAdd.c -o SeqAdd -lm

#include <stdio.h>
#include <pthread.h>
#include <math.h>
#include <string.h>
#include <unistd.h>

#define DIMROW 1000000
#define NUMROWS 20

typedef struct row{
        int vector[DIMROW];
        long addition;
} row;

row matrix[NUMROWS];

void *AddRow( void *ptr )
{
    int k;
    row *fi;
    fi=(row *)  ptr;

    fi->addition=0;
    for(k=0;k<DIMROW;k++) {
        fi->addition += exp((k*(fi->vector[k])+
                       (k+1)*(fi->vector[k]))/(fi->vector[k]+2*k))/2;
    }
}

int main()
{
    int i,j;
    long total_addition=0;
    pthread_attr_t atrib;

    // Vector elements initialized to 1
    for(i=0;i<NUMROWS;i++) {
        for(j=0;j<DIMROW;j++) {
            matrix[i].vector[j]=1;
        }
    }
    // Thread attributes initialization
    pthread_attr_init( &atrib );
	
    // EXERCISE 2.a
 	pthread_t threads[NUMROWS];
	int thread_args[NUMROWS];
	int rc;
    for(i=0;i<NUMROWS;i++){
      thread_args[i] = i;
      //printf("spawning thread %d\n", i);
      rc = pthread_create(&threads[i], NULL, AddRow, (void *) &matrix[i]);
       
    }
    
  /* wait for threads to finish */
  for (i=0; i<NUMROWS; ++i) {
    rc = pthread_join(threads[i], NULL);
  }

// EXERCISE 2.b

    for(i=0;i<NUMROWS;i++) 
        total_addition+=matrix[i].addition;
    printf(  "Total addition is: %ld\n",total_addition);

}

