// redir_output.c
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int main (int argc,char *argv[]) {
  int fd;
  char *arch= "salida.txt";
  mode_t fd_mode=S_IRWXU;// file permissions
 

  fd=open(arch,O_RDONLY,fd_mode);
 
if(dup2(fd,STDIN_FILENO)==-1){  //Redirigir el fd a la part de STD_IN per a poder efectuar la lectura 
	printf("Error calling dup2\n");
       	exit(-1); 
	}
//AHORA  como ya esta redirigido fd a la zona donde esta  STD_IN Solo debemos llamar  
//	al comando cat , este ya cogera por defecto lo que tengamos en la zona de  STD_IN que es el fd
//	si no hubieramos hecho el dup , realizaria un cat de STD_IN es decir de nada .
execl("/bin/cat","cat",NULL);
close(fd);
  return(0);
} 
