#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
main(void){
 pid_t pid;
 int x;
 for(x=1;x<=5;x++){
  pid=fork(); 
  if(pid){ //Si es 0(padre)
   printf("Soy el proceso %d\n",getpid());
    sleep(10);
   
  }else{
    printf( "Hijo creado en iteración=%d ID=%d",x,getpid());
   
    exit(x);
  } 
 }
}

/**En sistemas operativos Unix, un proceso  STAT Z+ zombie o “defunct” (difunto) es un proceso que ha completado su ejecución pero aún tiene una entrada en la tabla de procesos, permitiendo al proceso que lo ha creado leer el estado de su salida. Metafóricamente, el proceso hijo ha muerto pero su “alma” aún no ha sido recogida.**/
