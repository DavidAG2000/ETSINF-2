#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
 main(void){
 pid_t pid;
 int estado;
 int i;
 for(i=1;i<=2;i++){
  pid=fork(); 
  switch(pid){
		case -1: // Si pid es -1 quiere decir que ha habido un error
			perror("No se ha podido crear el proceso hijo\n");
			break;
		case 0: // Cuando pid es cero quiere decir que es el proceso hijo
			printf("Son %ld created in iteration %d\n",(long) getpid(),i);
			sleep(10);
			exit(i);
			break;
		default: // Cuando es distinto de cero es el padre
			printf("Father %ld, iteration %d\n", (long)getpid(),i);
			printf("I have created a son %ld\n",(long) pid);
		// La función wait detiene el proceso padre y se queda esperando hasta  que termine el hijo
			while(wait(&estado)>0){
				printf("	Father %ld iteration %d\n",(long) getpid(),i);
				printf( "	My son said %d\n",WEXITSTATUS(estado));
				printf( "	My son said %d\n", estado/256);
			}
			break;
	  }
	}
	
}

/** Con waitpid() aseguramos que el padre va a esperar a sus dos hijos antes de continuar, para prevenir que el proceso hijo quede en STAT Z+

**/



