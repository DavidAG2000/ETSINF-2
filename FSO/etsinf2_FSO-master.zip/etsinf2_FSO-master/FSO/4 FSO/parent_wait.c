#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
main(void){
 pid_t pid;
int estado;
int i;
 for(i=1;i<=2;i++){
  pid=fork(); 
  switch(pid){
		case -1: // Si pid es -1 quiere decir que ha habido un error
			perror("No se ha podido crear el proceso hijo\n");
			break;
		case 0: // Cuando pid es cero quiere decir que es el proceso hijo
			printf("I am %ld process, my parent is%ld\n",(long)getpid(),(long)getppid());
			break;
		default: // Cuando es distinto de cero es el padre
			printf("Parent process %ld \n", (long) getpid());
			// La función wait detiene el proceso padre y se queda esperando hasta
			// que termine el hijo
			wait(estado);
			printf("Mi proceso hijo ya ha terminado.\n");
			break;
		}
	}
}

/** Con waitpid() aseguramos que el padre va a esperar a sus dos hijos antes de continuar, para prevenir que el proceso hijo quede en STAT Z+

**/
