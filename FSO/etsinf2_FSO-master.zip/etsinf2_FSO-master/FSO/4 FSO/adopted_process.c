#include <stdio.h>
#include <unistd.h>
#include<stdlib.h>
main(void){
 pid_t pid;
 int x;
 for(x=1;x<=5;x++){
  pid=fork(); 
  if(pid){ //Si es 0(padre)
   printf("Soy el proceso %d\n",getpid());
    sleep(10);
   
  }else{
    printf( "Hijo creado en iteración=%d ID=%d",x,getpid());
   sleep(20);
    exit(x);
  } 
 }
}

/** De los procesos creados al ejecutar adopted_process ¿Qué proceso finaliza en primer lugar y como
afecta esta finalización al resto de procesos? 
El seu PPID pasa a ser 1 , xqe aquestos fills al no tindre al pare pase a ser adoptats per init().

**/
