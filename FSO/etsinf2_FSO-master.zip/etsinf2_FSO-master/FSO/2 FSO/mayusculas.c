#include <stdio.h> 
#define TAM_CADENA 200 
main() { 
    // Puntero a caracter para copiar las cadenas
    char *p1, *p2;
    
    // A) Define las variables cadena y cadena2 
    
    // B) Leer cadena de consola 
    
    
    // C) Convertir a may�sculas
    p1 = cadena;
    p2 = cadena2;
    while (*p1 != '\0') {
        // Copiar p1 a p2 restando 32
    }
    // Acordarse de poner el cero final en cadena2
    
    // D) Sacar por consola la cadena2.
}


