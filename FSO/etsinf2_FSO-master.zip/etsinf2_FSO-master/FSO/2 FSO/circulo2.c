#include <stdio.h>
#include "area.h"

int main() {   
   float area;
   float radio;
   radio = 10;
   printf("Area del circulo de radio %f es %f\n", radio, area(radio)); 
}

