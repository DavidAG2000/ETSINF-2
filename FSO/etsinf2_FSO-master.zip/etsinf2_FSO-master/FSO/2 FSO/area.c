#include <stdio.h>
#define PI 3.1416

float area(float radio){
	return PI * (radio * radio);
}

