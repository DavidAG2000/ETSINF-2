#include <stdio.h>
#include <unistd.h>
main(void){
 pid_t pid;
 int x;
 for(x=1;x<=3;x++)
  pid=fork(); 

  if(pid) //Si es 0(padre){
   printf("Soy el proceso %d\n",getpid());
   exit(X);
  }else{
    printf( "Hijo creado en iteración=%d ID=%d",x,getpid());
    sleep(10);
    exit(0);
  }
  
 }
 return 0;
}
